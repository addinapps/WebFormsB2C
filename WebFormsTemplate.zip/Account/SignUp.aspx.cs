﻿using Microsoft.Owin.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WEbFormsTemplate.Account
{
    public partial class SignUp : System.Web.UI.Page
    {
        public static string SignUpPolicyId = ConfigurationManager.AppSettings["ida:SignUpPolicyId"];

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                signedIn.Text = "You are not signed in.";
                claimType.Text = "";
                claimValue.Text = "";
                claimValueType.Text = "";
                claimSubjectName.Text = "";
                claimIssuer.Text = "";

                // To execute a policy, you simply need to trigger an OWIN challenge.
                // You can indicate which policy to use by adding it to the AuthenticationProperties using the
                // PolicyKey provided.
                HttpContext.Current.GetOwinContext().Authentication.Challenge(
                    new AuthenticationProperties()
                    {
                        RedirectUri = "/",
                    },
                    SignUpPolicyId);
            }
            else
            {
                ClaimsPrincipal claimsPrincipal = Thread.CurrentPrincipal as ClaimsPrincipal;

                if (claimsPrincipal != null)
                {
                    signedIn.Text = "You are signed in.";

                    foreach (Claim claim in claimsPrincipal.Claims)
                    {
                        claimType.Text = claim.Type;
                        claimValue.Text = claim.Value;
                        claimValueType.Text = claim.ValueType;
                        claimSubjectName.Text = claim.Subject.Name;
                        claimIssuer.Text = claim.Issuer;
                    }
                }
                else
                {
                    signedIn.Text = "You are not signed in.";
                }
            }
        }
    }
}